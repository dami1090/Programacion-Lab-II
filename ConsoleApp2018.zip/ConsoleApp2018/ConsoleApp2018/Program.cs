﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2018
{
    class Ejercicio_01
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 01";
            int num1,num2,num3,num4,num5;
           //int largo;
            //int[] vector;
           // vector = new int[5];
            int max = int.MaxValue;
            int min = int.MinValue;
            int i;
            int suma = 0;
            bool a;
            float prom;
           /* Console.WriteLine("ingrese un numero:\n");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ingrese un segundo numero:\n");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ingrese un tercer numero:\n");
            num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ingrese un cuarto numero:\n");
            vector[3] = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ingrese un quinto numero:\n");
            vector[4] = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("la suma del primer numero con el segundo es:");
            Console.WriteLine(vector[0] + vector[1]);
            */

            for(i=0;i<5;i++)
            {
                Console.WriteLine("ingrese un numero("+i+")");
                //num1 = Convert.ToInt32(Console.ReadLine());
                a = int.TryParse(Console.ReadLine(), out num1);
                suma = suma + num1;
                if(a == true)
                {
                    if (i == 0)
                    {
                        max = num1;
                        min = num1;
                    }
                    else if (num1 > max)
                    {
                        max = num1;
                    }
                    else if (num1 < min)
                    {
                        min = num1;
                    }
                }
                else
                {
                    Console.WriteLine("Lo cargaste mal, gato!");
                }
            }
            prom = (float)suma / i;
            Console.WriteLine("el promedio es: "+ prom);
            Console.WriteLine("el maximo es: " + max);
            Console.WriteLine("el minimo es: " + min);

            Console.ReadKey();
            


        }
    }
}
