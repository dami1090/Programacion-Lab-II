﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    class ejercicio_3
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 03";
            int num1,i,j,cont;
            bool esNum;
            Console.WriteLine("ingrese un numero:");
            esNum = int.TryParse(Console.ReadLine(), out num1);
            if (esNum == true)
            {
                for(i=2;i<num1;i++)
                {
                    cont = 0;
                    for (j = 1; j < num1; j++)
                    {
                        if (i % j == 0)
                        {
                            cont++;

                        }
                    }
                    if(cont ==2)
                    {
                        Console.WriteLine(i);
                    }
                    
                }
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("se ingreso mal el numero");
                Console.ReadKey();
            }
        }
    }
}
