﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio2
{
    class Ejercicio_2
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 02";
            int num1;
            bool esNum;
            Console.WriteLine("ingrese un numero:");
            esNum = int.TryParse(Console.ReadLine(), out num1);
            if(esNum==true)
            {
                Console.WriteLine("el cuadrado del numero:{0} es:{1}", num1, Math.Pow(num1, 2));
                Console.WriteLine("el cubo del numero:{0} es:{1}", num1, Math.Pow(num1, 3));
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("se ingreso mal el numero");
                Console.ReadKey();
            }
        }
    }
}
