﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    class ejercicio_4
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 04";
            int i,num1,cont;



            
            Console.ReadKey();
        }
    }
}
